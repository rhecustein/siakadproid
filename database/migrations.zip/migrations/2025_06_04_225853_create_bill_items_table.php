<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bill_items', function (Blueprint $table) {
            $table->id();

            $table->foreignId('bill_id')->constrained()->onDelete('cascade');
            $table->string('name');                        // e.g. "SPP Bulan Juli"
            $table->decimal('amount', 12, 2);              // Jumlah tagihan
            $table->enum('status', ['unpaid', 'partial', 'paid'])->default('unpaid');
            $table->date('due_date')->nullable();          // Tanggal jatuh tempo
            $table->date('paid_at')->nullable();           // Tanggal pembayaran (jika sudah dibayar)
            $table->string('gl_account')->nullable();      // Kode akuntansi jika diperlukan
            $table->text('notes')->nullable();             // Catatan internal

            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('bill_items');
    }
};
